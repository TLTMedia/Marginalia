export class Dom {

}
