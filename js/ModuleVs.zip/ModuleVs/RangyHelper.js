export class RangyHelper {

}
